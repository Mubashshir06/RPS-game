package com.mubashshir.rps;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
